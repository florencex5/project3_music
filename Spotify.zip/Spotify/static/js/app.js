d3.json("http://127.0.0.1:5000/tracks/genre/bangla").then(function (data) {
  banglaData = data;
  console.log(banglaData);
});


d3.json("http://127.0.0.1:5000/tracks/genre/desi").then(function (data) {
  desiData = data;
  console.log(desiData)
});


d3.json("http://127.0.0.1:5000/tracks/genre/minimal").then(function (data) {
  minimalData = data;
  console.log(minimalData)
});


d3.json("http://127.0.0.1:5000/tracks/year/2020").then(function (data) {
  year_20_Data = data;
  console.log(year_20_Data)
});


d3.json("http://127.0.0.1:5000/tracks/year/2021").then(function (data) {
  year_21_Data = data;
  console.log(year_21_Data)
});


d3.json("http://127.0.0.1:5000/tracks/year/2022").then(function (data) {
  year_22_Data = data;
  console.log(year_22_Data)
});


function openTableModal(genre) {

  function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }

  console.log('Modal opened for genre:', genre);

  // Set the modal header's title based on the clicked genre
  var modalHeader = document.querySelector('.modal-title');
  modalHeader.textContent = `${capitalizeFirstLetter(genre)} - Top 10 Songs`;

  // Show the modal
  const modal = document.getElementById("tableModal");
  modal.style.display = "block";

  // Add an event listener to close the modal when clicking outside of it
  window.addEventListener("click", function (event) {
    if (event.target === modal) {
      closeTableModal();
    }
  });

  // Add an event listener to close the modal when pressing the ESC key
  window.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
      closeTableModal();
    }
  });


  // Get the modal body where the table will be inserted
  const modalBody = document.querySelector('.modal-body');

  // Clear existing table rows if any
  modalBody.innerHTML = '';

  // Get the data for the selected genre (Assuming popData, rockData, and bluesData are globally accessible)
  const data = genre === 'bangla' ? banglaData :
    genre === 'desi' ? desiData :
      genre === 'minimal' ? minimalData : [];

  // Create the table element and add classes for styling
  const table = document.createElement('table');
  table.classList.add('table', 'table-striped', 'table-bordered');

  // Create the table header row
  const headerRow = document.createElement('tr');
  const headers = ['Track Name', 'Artist'];
  headers.forEach(headerText => {
    const th = document.createElement('th');
    th.textContent = headerText;
    headerRow.appendChild(th);
  });
  table.appendChild(headerRow);

  // Populate the table rows with data
  data.forEach(track => {
    const row = document.createElement('tr');
    row.innerHTML = `
    <td>${track.track_name}</td>
    <td>${track.artist}</td>
    `;
    table.appendChild(row);
  });

  // Append the table to the modal body
  modalBody.appendChild(table);

}


function closeTableModal(event) {
  // Hide the modal
  const modal = document.getElementById("tableModal");
  modal.style.display = "none";

}
