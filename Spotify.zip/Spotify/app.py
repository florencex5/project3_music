from flask import Flask, render_template, jsonify
from flask_cors import CORS

from utils import search_top_ten_tracks_by_genre, get_top_ten_songs_for_year

app = Flask(__name__)
CORS(app)


@app.route("/")
def dashboard():
    return render_template("dashboard.html")


@app.route("/tracks/genre/<genre>")
def top_ten_tracks_by_genre(genre):
    return search_top_ten_tracks_by_genre(genre)


@app.route("/tracks/year/<year>")
def top_ten_tracks_for_year(year):
    tracks_info = get_top_ten_songs_for_year(year)
    return render_template("tracks.html", tracks_info=tracks_info, year=year)


if __name__ == "__main__":
    app.run(debug=True)
