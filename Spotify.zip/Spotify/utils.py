import base64
import json
import requests

from decouple import config

from spotipy import Spotify
from spotipy.oauth2 import SpotifyClientCredentials


spotify = Spotify(
    client_credentials_manager=SpotifyClientCredentials(
        client_id=config("CLIENT_ID"), client_secret=config("CLIENT_SECRET")
    )
)


def get_token():
    auth_string = client_id + ":" + client_secret
    auth_bytes = auth_string.encode("utf-8")
    auth_base64 = str(base64.b64encode(auth_bytes), "utf-8")

    url = "https://accounts.spotify.com/api/token"

    headers = {
        "Authorization": "Basic " + auth_base64,
        "Content-Type": "application/x-www-form-urlencoded",
    }

    data = {"grant_type": "client_credentials"}
    result = requests.post(url, headers=headers, data=data)
    json_result = json.loads(result.content)

    token = json_result["access_token"]

    return token


def get_auth_header(token):
    return {"Authorization": "Bearer " + token}


def search_top_ten_tracks_by_genre(genre):
    # Search for the top tracks in the specified category
    results = spotify.search(q=f'genre:"{genre}"', type="track", limit=10)

    # Extract track information from the results
    top_10_tracks = results["tracks"]["items"]

    tracks = []
    for index, track in enumerate(top_10_tracks, start=1):
        tracks.append(
            {
                "track_name": track["name"],
                "artist": ", ".join(artist["name"] for artist in track["artists"]),
            }
        )

    return tracks


def get_top_ten_songs_for_year(year):
    # Search for the top tracks in the given year
    results = spotify.search(q=f'year:"{year}"', type="track", limit=10)

    # Extracting information from the JSON result
    tracks_info_list = []

    for entry in results["tracks"]["items"]:
        track_info = {
            "track": entry["name"].capitalize(),
            "artist": entry["artists"][0]["name"],
            "album": entry["album"]["name"],
            "release_date": entry["album"]["release_date"],
        }
        tracks_info_list.append(track_info)

    return tracks_info_list
